const form = document.getElementById("loginForm");

/* helpers */
function setError(input, error, mensaje) {
  if (error) error.textContent = mensaje;
  input.classList.add("invalido");
  input.classList.remove("valido");
}

function setValido(input, error) {
  if (error) error.textContent = "";
  input.classList.add("valido");
  input.classList.remove("invalido");
}

/* validar campo */
function validarCampo(input) {
  const error = document.getElementById("error-" + input.id);
  if (!input) return false;

  if (input.validity.valueMissing) {
    setError(input, error, "Este campo es obligatorio");
    return false;
  }

  if (input.type === "email" && input.validity.typeMismatch) {
    setError(input, error, "Correo inválido");
    return false;
  }

  if (input.id === "contrasena" && input.value.length < 6) {
    setError(input, error, "Mínimo 6 caracteres");
    return false;
  }

  setValido(input, error);
  return true;
}

/* debounce */
function debounce(func, delay = 300) {
  let timeout;
  return (...args) => {
    clearTimeout(timeout);
    timeout = setTimeout(() => func(...args), delay);
  };
}

/* eventos */
["correo", "contrasena"].forEach(id => {
  const input = document.getElementById(id);
  if (input) {
    input.addEventListener("blur", () => validarCampo(input));
    input.addEventListener("input", debounce(() => validarCampo(input), 300));
  }
});

/* submit */
/* Reemplaza la sección del submit en tu validateFormIS.js con esta */
form.addEventListener("submit", async (e) => {
  e.preventDefault();

  const inputs = form.querySelectorAll("input");
  let valido = true;

  inputs.forEach(input => {
    if (!validarCampo(input)) valido = false;
  });

  if (!valido) return;

  const datos = {
    correo: document.getElementById("correo").value,
    contrasena: document.getElementById("contrasena").value
  };

  try {
    const response = await fetch("/users/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(datos)
    });

    const resultado = await response.json();

    if (response.ok && resultado.success) {
      // Usamos 'nombre' en minúscula tal como viene de tu SQL Server
      const nombreUsuario = resultado.data.nombre || 'Usuario';
      
      // CORRECCIÓN DE RUTA: Mandamos a la ruta de login con el parámetro de consulta (?nombre=)
      // que es el que tu showWelcome en el controlador sabe leer (req.query.nombre)
      window.location.href = `/users/login/view?nombre=${encodeURIComponent(nombreUsuario)}`;
    } else {
      if (resultado.errors) {
        if (resultado.errors.correo) {
          setError(document.getElementById("correo"), document.getElementById("error-correo"), resultado.errors.correo);
        }
        if (resultado.errors.contrasena) {
          setError(document.getElementById("contrasena"), document.getElementById("error-contrasena"), resultado.errors.contrasena);
        }
        if (resultado.errors.general) {
          alert(resultado.errors.general);
        }
      } else {
        alert("Error: " + (resultado.message || "Credenciales incorrectas"));
      }
    }

  } catch (error) {
    console.error("Error en la petición:", error);
    alert("Error al conectar con el servidor. Verifica que tu API esté activa.");
  }
});