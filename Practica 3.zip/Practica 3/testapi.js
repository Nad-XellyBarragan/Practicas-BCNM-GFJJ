// testapi.js completo
import express from 'express';
import sql from 'mssql';

const app = express();
app.use(express.json());

// 1. CONFIGURACIÓN DE CONEXIÓN A TU SQL SERVER LOCAL
const dbConfig = {
    user: 'sa', // Tu usuario de SQL Server (visto en tu SSMS)
    password: '123', // !!! CAMBIA ESTO por tu contraseña real del usuario 'sa'
    server: 'localhost', 
    database: 'Users', // Tu base de datos que vimos en la captura
    options: {
        encrypt: false, // Ponlo en false para entorno local de desarrollo
        trustServerCertificate: true // Vital para evitar errores de certificados en Windows
    }
};

// 2. ENDPOINT: Buscar usuario por correo (El que llama usersService.js en el puerto 3000)
app.get('/api/sqlserver/getByEmail/:correo', async (req, res) => {
    const { correo } = req.params;
    try {
        let pool = await sql.connect(dbConfig);
        // Hacemos la consulta a tu tabla 'users' en minúsculas
        let result = await pool.request()
            .input('correoInput', sql.VarChar, correo)
            .query('SELECT id, nombre, correo, contrasena, preguntarc, respuestarc FROM dbo.users WHERE correo = @correoInput');
        
        // Si no encuentra al usuario, regresamos un array vacío o null
        if (result.recordset.length === 0) {
            return res.json([]);
        }
        
        // Devolvemos el array con el usuario encontrado
        res.json(result.recordset);
    } catch (error) {
        console.error("Error en la API de SQL Server:", error.message);
        res.status(500).json({ error: "Error al consultar SQL Server" });
    }
});

// 3. ENDPOINT: Registrar usuario nuevo en SQL Server
app.post('/api/sqlserver/register', async (req, res) => {
    const { nombre, correo, contrasena, preguntarc, respuestarc } = req.body;
    try {
        let pool = await sql.connect(dbConfig);
        await pool.request()
            .input('nombre', sql.VarChar, nombre)
            .input('correo', sql.VarChar, correo)
            .input('contrasena', sql.VarChar, contrasena)
            .input('preguntarc', sql.VarChar, preguntarc)
            .input('respuestarc', sql.VarChar, respuestarc)
            .query('INSERT INTO dbo.users (nombre, correo, contrasena, preguntarc, respuestarc) VALUES (@nombre, @correo, @contrasena, @preguntarc, @respuestarc)');
        
        res.json({ success: true });
    } catch (error) {
        console.error("Error al registrar en SQL Server:", error.message);
        res.status(500).json({ error: "Error al insertar en la base de datos" });
    }
});

// 4. ENDPOINT: Actualizar contraseña (Para tu recuperación de contraseña)
app.put('/api/sqlserver/updatePassword', async (req, res) => {
    const { correo, nuevaPass } = req.body;
    try {
        let pool = await sql.connect(dbConfig);
        await pool.request()
            .input('correo', sql.VarChar, correo)
            .input('nuevaPass', sql.VarChar, nuevaPass)
            .query('UPDATE dbo.users SET contrasena = @nuevaPass WHERE correo = @correo');
        
        res.json({ success: true });
    } catch (error) {
        console.error("Error al actualizar contraseña en SQL Server:", error.message);
        res.status(500).json({ error: "Error al actualizar la base de datos" });
    }
});

// 5. ARRANCAR EL SERVIDOR EN EL PUERTO 5000
const PORT = 5000;
app.listen(PORT, () => {
    console.log(`🚀 API de SQL Server corriendo con éxito en http://localhost:${PORT}`);
});