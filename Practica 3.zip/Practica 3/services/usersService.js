import bcrypt from 'bcrypt';

/**
 * 1. PROCESAR REGISTRO
 * Valida, hashea y envía los datos a la API de SQL Server (Puerto 5000)
 */
export const processForm = async (datos) => {
    const { nombre, contrasena, preguntarc, respuestarc, correo } = datos;
    const errores = {};

    // Validaciones de formato
    if (!nombre || !/^[A-Za-zÁÉÍÓÚáéíóúñÑ\s]+$/.test(nombre)) {
        errores.nombre = "El nombre solo debe contener letras";
    }
    if (!correo || !/^\S+@\S+\.\S+$/.test(correo)) {
        errores.correo = "Correo inválido";
    }
    if (!contrasena || contrasena.length < 6) {
        errores.contrasena = "La contraseña debe tener al menos 6 caracteres";
    }
    if (!respuestarc || respuestarc.length < 2) {
        errores.respuestarc = "Respuesta de seguridad inválida";
    }

    if (Object.keys(errores).length > 0) {
        return { success: false, errors: errores };
    }

    try {
        // A. Verificar si el usuario ya existe en SQL Server
        const checkUser = await fetch(`http://localhost:5000/api/sqlserver/getByEmail/${correo}`);
        const existingData = await checkUser.json();
        
        // Verificamos si la respuesta contiene datos (usuario ya registrado)
        const userExists = Array.isArray(existingData) ? existingData.length > 0 : !!existingData;

        if (userExists) {
            return {
                success: false,
                errors: { correo: "Este correo electrónico ya está registrado" }
            };
        }

        // B. Hasheo de seguridad (Vital para que validateUser funcione después)
        const saltRounds = 12;
        const contrasenaHash = await bcrypt.hash(contrasena, saltRounds);
        const respuestarcHash = await bcrypt.hash(respuestarc, saltRounds);

        const datosProcesados = {
            nombre,
            contrasena: contrasenaHash, // Se guarda el HASH, no texto plano
            preguntarc,
            respuestarc: respuestarcHash,
            correo,
            fecha: new Date().toISOString()
        };

        // C. Guardar en SQL Server a través de la API
        const response = await fetch('http://localhost:5000/api/sqlserver/register', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(datosProcesados)
        });

        if (!response.ok) throw new Error("Error en la inserción a la BD");

        return {
            success: true,
            errors: null,
            data: { nombre, correo } 
        };

    } catch (err) {
        console.error("Error en el proceso de registro:", err.message);
        return {
            success: false,
            errors: { general: "Error de conexión con la base de datos" }
        };
    }
};

/**
 * 2. VALIDAR LOGIN
 * Compara la contraseña ingresada contra el HASH almacenado en SQL Server
 */
export const validateUser = async (correo, contrasena) => {
    try {
        const response = await fetch(`http://localhost:5000/api/sqlserver/getByEmail/${correo}`);
        
        if (!response.ok) {
            return {
                success: false,
                errors: { general: 'Error de comunicación con la base de datos' }
            };
        }

        const data = await response.json();
        // SQL Server suele devolver un array: [ {datos} ]
        const user = Array.isArray(data) ? data[0] : data;

        if (!user) {
            return {
                success: false,
                errors: { correo: 'Usuario no encontrado' }
            };
        }

        const dbPassword = user.contrasena;

        if (!dbPassword) {
            return { success: false, errors: { general: 'Estructura de BD incorrecta' } };
        }

        // Bcrypt comparará el texto plano con el hash de la BD
        const match = await bcrypt.compare(contrasena, dbPassword);
        
        if (!match) {
            return {
                success: false,
                errors: { contrasena: 'Contraseña incorrecta' }
            };
        }

        return {
            success: true,
            errors: null,
            data: user // Contiene id, nombre, correo, etc.
        };

    } catch (err) {
        console.error("Error en validateUser:", err.message);
        return {
            success: false,
            errors: { general: 'Error interno del servidor de datos' }
        };
    }
};

/**
 * 3. BUSCAR POR CORREO (Para recuperación)
 */
export const buscarPorCorreo = async (correo) => {
    try {
        const response = await fetch(`http://localhost:5000/api/sqlserver/getByEmail/${correo}`);
        if (!response.ok) return null;
        
        const data = await response.json();
        // Retornamos el primer usuario encontrado o null
        return Array.isArray(data) ? data[0] : data;
    } catch (error) {
        console.error("Error en buscarPorCorreo:", error);
        return null;
    }
};