import express from "express";
import { showFormRegister, showRecovery, showWelcome, registerUser, loginUser, showFormLogin } from "../controllers/usersController.js";
import * as usersController from '../controllers/usersController.js';

const router = express.Router();

// Rutas de Registro
router.get("/registro", showFormRegister);
router.post("/registro", registerUser);

// Rutas de Login (Manejamos el POST y la vista GET)
router.post("/login", loginUser);
router.get("/login/view", showWelcome); // CORRECCIÓN: Esta ruta recibirá el ?nombre=...

// Rutas de Recuperación y API complementaria
router.get("/recory", showRecovery);
router.get('/buscar-pregunta', usersController.obtenerPregunta);
router.post('/verificar-respuesta', usersController.verificarRespuesta);
router.get('/nueva-password-view', usersController.showNuevaPassword);
router.post('/actualizar-password', usersController.actualizarPassword);

export default router;